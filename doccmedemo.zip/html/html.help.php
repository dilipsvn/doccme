<?php
/*
 * Created on 1 Feb, 2008
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
?>
<div id="ContentMainDesc">
	<div class = "contentMainHeader">
	Help
	</div>
	<div class="textContent">
	<p>Directions for how to add/remove specialities<br/> in the text field <br/>  
	<p>1.Add Speciality to the text field above :-
	<br/>Select speciality from the <br/>drop down list and click "Add" button.</p>
	 <p>2.Remove Speciality to the text field above :-
	<br/>Select speciality from the drop <br/>down list and click "Remove" button.</p>	
	</p>
	</div>
	
 <div style="margin-left:90px;"> <input type="button" name="close" value="Close" onclick="window.close();"/></div>
  
  
</div>
