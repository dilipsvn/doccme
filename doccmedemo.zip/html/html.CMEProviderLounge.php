<!-- <div id="ContentMainImage">
	<img src="./images/CMEProvider.jpg" alt="CME Provider Lounge" />
</div> -->
<div id="ContentMainDesc">
	<div class = "contentMainHeader">
		CME Provider&acute;s Lounge
	</div>	
	<div class="textContent">
		<b> Dear CME Administrators,</b>
		<p>I am Dr Reshi. CEO of DocCME Inc. I welcome you to our company. Our goal is to connect you to your customer (the doctor). Our program will help you as follows:</p>
		<ol>
			<li>Improve profits by reducing payrolls.</li>
			<li>Reduce the number of calls to your office.</li>
			<li>Improve profits by reducing your advertisement costs.</li>
		</ol>
	</div>
	<div class="textContent">
		<b> If you are a registered user, please <a href="login.php?p=CMEProvider"><img src="images/login_but.gif" Style="width:55px; height: 22px; border: none;" alt="Login" /> </a>or Click here to <a href="cmeProviderRegister.php"><span class="highlightContent">  Sign Up </span></a> for free.</b>
	</div>
</div>
