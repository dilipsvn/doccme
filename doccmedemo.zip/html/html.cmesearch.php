<div id="ContentMainDesc">
	<div class = "contentMainHeader">
		Cme Course Search
	</div>
	<div class="textContent">
		<h3>You are not Authorize to CME Course search.</h3><br/>
		If you are registered as Doctor please <b><a href="login.php?p=DOCTOR">Login</a></b>.<br/>
		OR<br/>
		Please<b> <a href="docRegister.php">Register </a></b>with us to use this facility.
	</div>
</div>