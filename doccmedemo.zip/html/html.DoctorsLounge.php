<script language="JavaScript" type="text/javascript" >
function modelesswin(url,mwidth,mheight)
{
if (document.all && window.print) //if ie5
eval('window.showModelessDialog(url,"","help:0;resizable:1;dialogWidth:'+mwidth+'px;dialogHeight:'+mheight+'px")')
else
eval('window.open(url,"","width='+mwidth+'px,height='+mheight+'px,resizable=1,scrollbars=1")')
}
</script>
<!-- <div id="ContentMainImage">
	<img src="./images/DoctorLounge.jpg" alt="Doctor Lounge" />
</div> -->
<div id="ContentMainDesc">
	<div class = "contentMainHeader">
		Doctor&acute;s Lounge
	</div>
	<div class="textContent">
		<p> Our aim is to take your CME experience to a higher level. We have compiled the most extensive data on the basis of available CMEs so that you can find the CME of your choice.
		</p>
		<p>We understand the value of your time. When you are ready to book a CME, all you need to do is give us a call or visit our webpage and do a simple search to find the CME of your choice. We will book it right away.</p>
		<p> Try us out today by giving us a call at  <span class="highlightContent">+1-866-465-6181</span> Or dropping an
		<a  href="javascript:var mywin=window.open('./emailUs.php','Email','toolbar=no,status=no,menubar=no,resizeable=no,width=342,height=180,titlebar=no');">
		<span class = "highlight"> Email</span>		</a>   for more information. Our customer service agents will call you back.		</p>
	</div>	
	<div class="textContent">
	<b>If you are a registered user, please click here to login
		<a href="login.php?p=DOCTOR">
		<img src="images/login_but.gif" Style="width:55px; height: 22px; border: none;" alt="Login"  />
 		</a><br/>
 		OR<br/>
       Click here to  <a href="docRegister.php">
        <span class="highlightContent">join us</span> </a>  for free</b>.<br/>
	<div id = "mandatoryFields">Note : Please press Ctrl + Click to remove pop-up blocker</div>
	</div>
	
	<br/>
  <hr width="740!"! size="2">
  <br/>
 <div class="textContent">
  <a  href="javascript:var mywin=window.open('./referFriend.php','Referral','toolbar=no,status=no,menubar=no,resizeable=no,width=342,height=180,titlebar=no');">
  <span class="highlight">If you like DocCME  do you want to recommend it to a friend?
</span>
</a><br/>
<div id="CallEmailUsSectionIndex">
		<div class="CallUsButton">
			<img src="./images/phone_num.gif" width="172px" height="21px"/>
		</div>
		<div class = "CallEmailContent">or</div>
		<div class="EmailUsButton">
			<a  href="javascript:var mywin=window.open('./emailUs.php','Email','toolbar=no,status=no,menubar=no,resizeable=no,width=342,height=180,titlebar=no');">
				<img src="./images/email_but.gif" width="172px" height="21px" border="0"/>
			</a>
		</div>
		<div class="clearFloatLeft"></div>
	</div>
</p>
 </div>

</div>
