<?php
$_SESSION["UserId"]= "";
 		$_SESSION["UserName"] = "";
 		$_SESSION["Role"] = "";
?>
<div id="ContentMainDesc">
	<div class = "contentMainHeader">
	Logout
	</div>
	<h3>You have successfully logged out</h3>
</div>
	