<div id="ContentMainDesc">
	<div class = "contentMainHeader">
	Contact Us
	</div>
	<div class="textContent">
	<div class="imgright">
					<img src="./images/stetho1.jpg" width="159" height="152" />
	</div>
	
	<b>DocCME Inc. (Division of Global</b><br/>
	<b>Access Med, LLC.)  </b><br/>
	3470 Washington Drive, # 207 <br/>
	Eagan, MN 55122<br/>
	Phone: 651.204.2492<br/>
	Fax:651.452.6239<br/>
	Email:<a href="mailto:info@docCME.com">Info@docCME.com</a><br/>
	</div>
	<div class="clearFloatRight"></div>
	
</div>
