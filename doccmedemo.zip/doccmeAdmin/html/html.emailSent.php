<?php
/*
 * Created on Oct 31, 2007
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
?>
<div id="ContentMainDesc">
	<div class = "contentMainHeader">
	Email Sent
	</div>
	<div class="textContent">
	Email has been sent to you with your login details
	</div>
	<div class="textContent">
	<a href = "./index.php">Login Page</a>
	</div>
</div>