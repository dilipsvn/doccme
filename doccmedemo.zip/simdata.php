<?
// You may want to store this more securely in a DB or Registry or a Encrypted File
$loginid = "69SV9wb2qR";
$x_tran_key = "6W9Y72m48Dquy2Yq";
//$loginid = "authnet06";
//$x_tran_key = "Authnet44";
?>
